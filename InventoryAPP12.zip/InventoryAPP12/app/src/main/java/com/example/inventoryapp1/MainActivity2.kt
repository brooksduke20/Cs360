package com.example.inventoryapp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

          var edittext:EditText = findViewById(R.id.input)
             val button:Button = findViewById(R.id.add_item)

             var listview:ListView = findViewById(R.id.listView)

        var itemlist = arrayListOf<String>()

        button.setOnClickListener {
            itemlist.add(edittext.text.toString())

            }

            listview.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,itemlist)
        }


    }
}

